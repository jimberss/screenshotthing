﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;

namespace ScreenshotClient
{
    internal class Program
    {
        static void Main(string[] args)
        {

            CaptureScreen();
        }
        static void CaptureScreen()
        {
            TcpClient tcpclnt = new TcpClient();

            tcpclnt.Connect("192.168.0.24", 25565);

            Stream stream = tcpclnt.GetStream();
            bool exit = false;
            do
            {
                string fileName = @"C://Users/" + Environment.UserName + "/Downloads/temp.png";
                // CODE FOR SCREENSHOT
                //take a screenshot and save it as a bitmap
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                Bitmap memoryImage;
                memoryImage = new Bitmap(1920, 1080);
                Size s = new Size(memoryImage.Width, memoryImage.Height);

                Graphics memoryGraphics = Graphics.FromImage(memoryImage);

                memoryGraphics.CopyFromScreen(0, 0, 0, 0, s);

                //save img

                memoryImage.Save(fileName);

                //send image

                ImageConverter _imageConverter = new ImageConverter();
                byte[] data = (byte[])_imageConverter.ConvertTo(memoryImage, typeof(byte[]));

                int bufferSize = 1024;

                byte[] dataLength = BitConverter.GetBytes(data.Length);

                stream.Write(dataLength, 0, 4);

                int bytesSent = 0;
                int bytesLeft = data.Length;

                while (bytesLeft > 0)
                {
                    int curDataSize = Math.Min(bufferSize, bytesLeft);

                    stream.Write(data, bytesSent, curDataSize);

                    bytesSent += curDataSize;
                    bytesLeft -= curDataSize;
                }
            } while (exit == false);
        }
    }
}
