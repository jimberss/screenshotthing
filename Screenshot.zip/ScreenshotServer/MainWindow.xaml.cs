﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ScreenshotServer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int counter = 0;
        public MainWindow()
        {
            InitializeComponent();

            TcpListener listen = new TcpListener(IPAddress.Any, 25565);
            TcpClient client;

            // Start listening
            listen.Start();
            // Accept client
            client = listen.AcceptTcpClient();
            NetworkStream netStream;
            netStream = client.GetStream();
            Listener(listen, client, netStream);


        }
        public void Listener(TcpListener listen, TcpClient client, NetworkStream netStream)
        {

            ImageSource screenshot;
                int bufferSize = 1024;

                int bytesRead = 0;
                int allBytesRead = 0;

            
                // Read length of incoming data
                byte[] length = new byte[4];
                bytesRead = netStream.Read(length, 0, 4);
                int dataLength = BitConverter.ToInt32(length, 0);

                // Read the data
                int bytesLeft = dataLength;
                byte[] data = new byte[dataLength];

                while (bytesLeft > 0)
                {

                    int nextPacketSize = (bytesLeft > bufferSize) ? bufferSize : bytesLeft;

                    bytesRead = netStream.Read(data, allBytesRead, nextPacketSize);
                    allBytesRead += bytesRead;
                    bytesLeft -= bytesRead;


                // Save img
                    if (counter == 1)
                    {
                        File.WriteAllBytes("C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp.jpg", data);
                    }
                    else if (counter == 0)
                    {
                        File.WriteAllBytes("C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp1.jpg", data);
                    }
                }
                //load image to winform and delete other temp
                if (counter == 1)
                {
                    screenshot = new BitmapImage(new Uri("C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp.jpg"));
                    screenshotload.Source = screenshot;
                    counter = 0;
                }
                else if (counter == 0)
                {
                    screenshot = new BitmapImage(new Uri("C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp1.jpg"));
                    screenshotload.Source = screenshot;
                    counter = 1;
                }
                //creates third temp and deletes previous 2
                deletescreenshot();
        }
        public void deletescreenshot()
        {
            if(counter == 1)
            {
                string sourceFile = "C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp1.jpg";
                string destinationFile = "C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp3.jpg";
                try
                {
                    File.Copy(sourceFile, destinationFile, true);
                    ImageSource screenshot;
                    screenshot = new BitmapImage(new Uri(destinationFile));
                    screenshotload.Source = screenshot;
                    File.Delete(sourceFile);

                }
                catch (IOException iox) { }
            }
            else if(counter == 0)
            {
                string sourceFile = "C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp2.jpg";
                string destinationFile = "C:\\Users\\rowan\\Desktop\\ScreenshotServer\\temp4.jpg";
                try
                {
                    File.Copy(sourceFile, destinationFile, true);
                    ImageSource screenshot;
                    screenshot = new BitmapImage(new Uri(destinationFile));
                    screenshotload.Source = screenshot;
                    File.Delete(sourceFile);

                }
                catch (IOException iox) { }
            }
        }

    }
}
